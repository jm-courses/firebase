> **Note** :
> Ce dossier constitue la base du projet de travail pour le cours de Firebase de cette semaine.
> **Vous devez le récupérer juste avant de démarrer l'activité vidéo 03AN**