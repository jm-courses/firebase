> **Warning** :
> Ce dossier ne contient que les **corrigés** des fichiers (ayants été mis à jour ou nouvellement créés) pour l'exercice précédent.
> C'est à vous de les consulter et (si besoin) de les adapter à votre base du projet `firebase-playground-base`

> **Note** :
> Si vous avez réussi l'exercice demandé, cette correction est simplement à titre indicatif et ne constitue pas une obligation d'intégration à votre base de projet personnel.